# base-de-datos-y-algoritmos
Elaboracion de tablas en SQLite y aplicacion de diversos algoritmos
